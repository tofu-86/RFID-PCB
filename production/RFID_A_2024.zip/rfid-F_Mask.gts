G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.5*
G04 #@! TF.CreationDate,2026-02-12T18:17:23+00:00*
G04 #@! TF.ProjectId,rfid,72666964-2e6b-4696-9361-645f70636258,A_ 2024*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.5) date 2026-02-12 18:17:23*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,6.000000*%
%ADD11RoundRect,0.237500X-0.237500X0.250000X-0.237500X-0.250000X0.237500X-0.250000X0.237500X0.250000X0*%
%ADD12C,1.200000*%
%ADD13C,0.900000*%
%ADD14C,1.778000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H3*
X109500000Y-89500000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,R10*
X47000000Y-49087500D03*
X47000000Y-50912500D03*
G04 #@! TD*
D10*
G04 #@! TO.C,H2*
X109500000Y-17500000D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X17500000Y-17500000D03*
G04 #@! TD*
G04 #@! TO.C,H4*
X17500000Y-89500000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,LCD1*
X77750000Y-41874910D03*
X76250000Y-41874910D03*
X74750000Y-41874910D03*
X73250000Y-41874910D03*
X71750000Y-41874910D03*
X70250000Y-41874910D03*
X68750000Y-41874910D03*
X67250000Y-41874910D03*
G04 #@! TD*
D13*
G04 #@! TO.C,SW2*
X29500000Y-58750000D03*
X26500000Y-58750000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,X1*
X35080000Y-82500000D03*
X24920000Y-82500000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,SW1*
X31150000Y-67775000D03*
X24350000Y-67775000D03*
G04 #@! TD*
M02*
